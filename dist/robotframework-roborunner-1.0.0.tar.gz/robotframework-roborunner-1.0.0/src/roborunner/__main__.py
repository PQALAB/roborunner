from roborunner import run
from sys import argv

if __name__ == "__main__":
    run()

